# Game Hacking

- The Ultimate Game Hacking Resource: A curated list of tools, tutorials, and much more for reverse engineering video games!
https://github.com/dsasmblr/game-hacking

- The Ultimate Online Game Hacking Resource: https://github.com/dsasmblr/hacking-online-games
