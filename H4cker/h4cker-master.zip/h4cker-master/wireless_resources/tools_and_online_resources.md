# Tools

## Hak5's Wi-Fi Pineapple

Fully-integrated Wi-Fi man-in-the-middle platform and rogue access point.

* [Site](https://www.wifipineapple.com/)
* [Store](https://hakshop.com/products/wifi-pineapple)
* [Wiki](https://wiki.wifipineapple.com/)

## Aircrack-ng

Complete suite of tools to monitor, capture, export, attack and crack wireless
networks.

* [Site](https://www.aircrack-ng.org/)

## Airsnort

* [Site](https://sourceforge.net/projects/airsnort/)

## Kismet

Useful for troubleshooting Wi-Fi networks.  Detects hidden networks.

* [Site](https://www.kismetwireless.net/)

## Kismac-ng

Network stumbling tool that works on Mac OS X and features support for built-in
WLAN NICs on some Macs.

* [Site](http://kismac-ng.org/)

## Fern WiFi Cracker

Automated cracking and nice monitoring capabilities.  Very easy to use.

* [Site](http://www.fern-pro.com/)

## Cowpatty

Features offline dictionary cracking for WPA networks.

* [Site](http://www.willhackforsushi.com/?page_id=50)

## Ghost Phisher

Tool designed around sniffing passwords with an AP emulator, DHCP/DNS/HTTP 
server and logging to a built-in database.

* [Site](https://github.com/savio-code/ghost-phisher)

# Online Wireless Resources

## Wigle.net

Consolidated location and information of wireless networks world-wide in a
centralized database--queried and updated via web app, native clients and
mobile applications.

* [Site](https://wigle.net/)

