# Metasploit Resources

* [Offensive Security Metasploit Unleashed Free Course](https://www.offensive-security.com/metasploit-unleashed/) - a free course from the folks at Offensive Security created to help raise awareness for underprivileged children in East Africa. Please make a donation to the Hackers For Charity non-profit 501(c)(3) organization. A sum of $9.00 will feed a child for a month, so any contribution makes a difference.

* Don't forget to always update Metasploit - `msfupdate`

* [A Good Summary of Metasploit Commands](https://www.hackingtutorials.org/metasploit-tutorials/metasploit-commands/)
