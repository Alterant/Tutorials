# :octocat: Additional Resources and Lists
- [Additional hacking resources for beginners](https://github.com/Amanchouhan192/Awesome-Hacking)
- [Awesome Python](https://github.com/vinta/awesome-python)
- [Awesome Bash](https://github.com/awesome-lists/awesome-bash)
- [Awesome Shell](https://github.com/alebcay/awesome-shell)
