# VIRL Topologies
This folder includes the Virtual Internet Routing Lab Personal Edition (VIRL PE) topologies used in [The security penetration testing (the art of hacking series) video course](https://www.safaribooksonline.com/library/view/security-penetration-testing/9780134833989/sptt_00_08_07_00.html).

[VIRL](http://get.virl.info/) is a powerful network virtualization and orchestration platform that enables the development of highly accurate models of existing or planned networks.
