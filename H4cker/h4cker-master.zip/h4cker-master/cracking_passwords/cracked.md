# Cracked Passwords
The following are the cracked passwords of "Exercise 1: Cracking Passwords with John the Ripper" of the Safari Live Training: Ethical Hacking Bootcamp by Omar Santos

```
root@kali:~# john hashes
Warning: detected hash type "sha512crypt", but the string is also recognized as "crypt"
Use the "--format=crypt" option to force loading these as that type instead
Using default input encoding: UTF-8
Loaded 3 password hashes with 3 different salts (sha512crypt, crypt(3) $6$ [SHA512 128/128 AVX 2x])
Press 'q' or Ctrl-C to abort, almost any other key for status
letmein          (batman)
password1        (superman)
password         (spiderman)
3g 0:00:00:08 DONE 2/3 (2019-01-12 21:22) 0.3496g/s 1038p/s 1053c/s 1053C/s 123456..green
Use the "--show" option to display all of the cracked passwords reliably
Session completed
root@kali:~#
```
