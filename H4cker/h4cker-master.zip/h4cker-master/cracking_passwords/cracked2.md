# Cracked Passwords
The following are the cracked passwords of "Exercise 1.2: Cracking Passwords with John the Ripper" of the Safari Live Training: Ethical Hacking Bootcamp by Omar Santos

```
root@kali:~# cat cracked.txt
476c6c4a9735ecaff882a6e01bcda6e8:blue123
17a807c3a10ee2d8ed555ddfb8c0f790:boricua
d0f98c2b1656b2f20c731d086dc68d1c:destiny1
dc647eb65e6711e155375218212b3964:Password
```
